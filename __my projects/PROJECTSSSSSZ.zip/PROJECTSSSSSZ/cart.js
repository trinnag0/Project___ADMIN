let iconCart = document.querySelector('.iconCart');
let cart = document.querySelector('.cart');
let container = document.querySelector('.container');
let close = document.querySelector('.close');

// LocalStorage helpers for reviews
function getReviewsMap() {
    try {
        return JSON.parse(localStorage.getItem('reviews')) || {};
    } catch (e) {
        return {};
    }
}

function saveReviewsMap(map) {
    try {
        localStorage.setItem('reviews', JSON.stringify(map));
    } catch (e) {
        // no-op
    }
}

function getReviewsFor(productId) {
    const map = getReviewsMap();
    return map[productId] || [];
}

function addReview(productId, rating, comment) {
    const map = getReviewsMap();
    if (!map[productId]) map[productId] = [];
    map[productId].push({ rating: Number(rating), comment: (comment || '').toString(), ts: Date.now() });
    saveReviewsMap(map);
}

function getRatingSummary(productId) {
    const list = getReviewsFor(productId);
    if (!list.length) return { average: 0, count: 0 };
    const sum = list.reduce((acc, r) => acc + (Number(r.rating) || 0), 0);
    const avg = sum / list.length;
    return { average: avg, count: list.length };
}

iconCart.addEventListener('click', () => {
    if (cart.style.right == '0px' || cart.style.right == '0') {
        cart.style.right = '-100%';
        container.style.transform = 'translateX(0)';
    } else {
        cart.style.right = '0';
        container.style.transform = 'translateX(-400px)';
    }
});

close.addEventListener('click', () => {
    cart.style.right = '-100%';
    container.style.transform = 'translate(0)';
});

let products = null;
// Get data from JSON file
fetch('product.json')
    .then(response => response.json())
    .then(data => {
        products = data;
        addDataToHTML();
    });

// Show data in list HTML
function addDataToHTML() {
    // Remove default data in HTML
    let listProductHTML = document.querySelector('.listProduct');
    listProductHTML.innerHTML = '';

    // Add new data
    if (products != null) {
        products.forEach(product => {
            let newProduct = document.createElement('div');
            newProduct.classList.add('item');
            const priceText = (product.price ?? '').toString();
            const isDescriptive = /[a-zA-Z%]/.test(priceText);
            const hasRange = /-|\bto\b/i.test(priceText);
            const priceNumeric = parseFloat(priceText.replace(/[^0-9.]/g, '')) || 0;
            const displayPriceText = (isDescriptive || hasRange) ? priceText : `₹ ${priceNumeric.toFixed(2)}`;
            const rating = getRatingSummary(product.id);
            const stars = '★★★★★';
            const filled = Math.round(rating.average);
            const starHTML = `<span class="stars" aria-label="${rating.average.toFixed(1)} out of 5">` +
                `<span style="color:#f5a623">${stars.slice(0, filled)}</span><span style="color:#ccc">${stars.slice(filled)}</span>` +
                `</span>`;
            newProduct.innerHTML = `
                <img src="${product.image}" alt="${product.name}">
                <h2>${product.name}</h2>
                <div class="ratingRow">${starHTML} <span class="ratingText">${rating.count} reviews</span></div>
                <div class="price">${displayPriceText}</div>
                <div class="actions"><button onclick="addCart(${product.id})">Add To Cart</button></div>
            `;
            listProductHTML.appendChild(newProduct);
        });
    }
}

let listCart = [];
// Get cookie data cart
function checkCart() {
    var cookieValue = document.cookie
        .split(';')
        .find(row => row.trim().startsWith('listCart='));
    if (cookieValue) {
        listCart = JSON.parse(cookieValue.split('=')[1]);
    }
    addCartToHTML();
}
checkCart();

// Utility to show a floating message when an item is added to cart
function showAddToCartMessage(productName) {
    let msg = document.createElement('div');
    msg.className = 'add-to-cart-message';
    msg.innerText = `${productName} has been added to cart!`;
    document.body.appendChild(msg);
    setTimeout(() => {
        msg.classList.add('fade-out');
        setTimeout(() => document.body.removeChild(msg), 600);
    }, 1200);
}

function addCart(idProduct) {
    let productCopy = JSON.parse(JSON.stringify(products));
    // If this product is not in the cart
    let productInCart = listCart.find(product => product.id === idProduct);
    if (!productInCart) {
        let dataProduct = productCopy.find(product => product.id === idProduct);
        // Add data product to cart
        dataProduct.quantity = 1;
        listCart.push(dataProduct);
        showAddToCartMessage(dataProduct.name); // Show message
    } else {
        // If this product is already in the cart, increase the quantity
        productInCart.quantity++;
        let dataProduct = productCopy.find(product => product.id === idProduct);
        showAddToCartMessage(dataProduct.name); // Show message
    }
    // Save data cart in cookie to persist data
    let timeSave = "expires=Thu, 18 Dec 2025 12:00:00 UTC";
    document.cookie = "listCart=" + JSON.stringify(listCart) + ";" + timeSave + ";path=/";
    addCartToHTML();
}

function addCartToHTML() {
    // Clear default data
    let listCartHTML = document.querySelector('.listCart');
    listCartHTML.innerHTML = '';
    let totalHTML = document.querySelector('.totalQuantity');
    let totalQuantity = 0;

    if (listCart) {
        listCart.forEach(product => {
            if (product) {
                let newCart = document.createElement('div');
                newCart.classList.add('item');
                const priceText = (product.price ?? '').toString();
                const isDescriptive = /[a-zA-Z%]/.test(priceText);
                const hasRange = /-|\bto\b/i.test(priceText);
                let priceNumeric = parseFloat(priceText.replace(/[^0-9.]/g, ''));
                if (isNaN(priceNumeric) || priceNumeric < 1) priceNumeric = 5.00;
                const displayPriceText = (isDescriptive || hasRange) ? priceText : `₹ ${priceNumeric.toFixed(2)}`;
                let totalDisplay = (hasRange) ? 'Varies' : `₹ ${(priceNumeric * product.quantity).toFixed(2)}`;
                newCart.innerHTML = `
                    <img src="${product.image}" alt="${product.name}">
                    <div class="content">
                        <div class="name">${product.name}</div>
                        <div class="price">${displayPriceText}</div>
                    </div>
                    <div class="quantity" style="display:flex;align-items:center;gap:8px;">
                        <button onclick="changeQuantity(${product.id}, '-')">-</button>
                        <span class="value">${product.quantity}</span>
                        <button onclick="changeQuantity(${product.id}, '+')">+</button>
                    </div>
                    <div class="returnPrice">${totalDisplay}</div>
                `;
                listCartHTML.appendChild(newCart);
                totalQuantity += product.quantity;
            }
        });
    }
    totalHTML.innerText = totalQuantity;
}

function changeQuantity(idProduct, type) {
    let productInCart = listCart.find(product => product.id === idProduct);
    if (productInCart) {
        switch (type) {
            case '+':
                productInCart.quantity++;
                break;
            case '-':
                productInCart.quantity--;
                if (productInCart.quantity <= 0) {
                    listCart = listCart.filter(product => product.id !== idProduct);
                }
                break;
            default:
                break;
        }
        // Save new data in cookie
        let timeSave = "expires=Thu, 18 Dec 2025 12:00:00 UTC";
        document.cookie = "listCart=" + JSON.stringify(listCart) + ";" + timeSave + ";path=/";

        // Reload list cart in HTML
        addCartToHTML();
    }
}