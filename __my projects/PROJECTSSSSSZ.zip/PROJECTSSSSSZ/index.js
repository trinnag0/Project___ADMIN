const clock = document.getElementById('clock');
function updateDate(){

    const Now = new Date();
    let Hours = Now.getHours();
    let minutes = Now.getMinutes();
    let seconds = Now.getSeconds();


    Hours = Hours < 10 ? '0' + Hours : Hours;
  minutes = minutes < 10 ? '0' + minutes: minutes;
  seconds = seconds < 10 ? '0' + seconds : seconds;


    const TimeString = `${Hours}:${minutes}:${seconds}`;
clock.textContent = TimeString;

}
updateDate();

setInterval(updateDate, 1000);